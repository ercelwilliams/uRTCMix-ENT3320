# Services Core
This package defines common components used by multiple Game Service packages.
These are standardized and aim to unify the overall experience of working with Game Service packages.
