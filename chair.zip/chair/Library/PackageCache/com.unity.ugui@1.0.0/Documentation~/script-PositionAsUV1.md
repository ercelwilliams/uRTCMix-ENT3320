# Position as UV1

This adds a simple Position as UV1 effect to text and image graphics.

## Properties

![](images/UI_PositionAsUV1Inspector.png)

|**Property:** |**Function:** |
|:---|:---|
|**Script** |  |
